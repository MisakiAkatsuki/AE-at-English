﻿AE at English
  (C) あかつきみさき(みくちぃP)

このbatについて
  After Effectsを一時的に英語版で起動するbatファイルです.

使用方法
  インストールされているAfter Effectsのバージョンにあったbatファイルを実行してください.

動作環境
  Windows版 Adobe After Effects CS4以上

バージョン情報
  2016/11/04 Ver 1.5.0 Update
    After Effects CC 2017に対応
    batファイルのエンコードをUTF-8にした

  2016/06/23 Ver 1.4.0 Update
    After Effects CC 2015.3に対応

  2015/06/16 Ver 1.3.0 Update
    After Effects CC 2015に対応

  2014/06/20 Ver 1.2.0 Update
    After Effects CC 2014に対応

  2013/06/18 Ver 1.1.0 Update
    After Effects CCに対応

  2012/07/27 Ver 1.0.0 Release
